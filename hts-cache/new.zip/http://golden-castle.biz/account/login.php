<!DOCTYPE html>
<html lang="en">
<head>
	<title></title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="assets/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="assets/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/css/util.css">
	<link rel="stylesheet" type="text/css" href="assets/css/main.css">
    <link rel="stylesheet" type="text/css" href="assets/css/parsley.css">
<!--===============================================================================================-->
    <script src="assets/vendor/jquery/jquery-3.2.1.min.js"></script>
</head>
<body>	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/city.jpg');" id="particles-js">
			<div class="wrap-login100 p-t-190 p-b-30" style="z-index:100">
				<form class="login100-form" id="loginform" method="post" action="connect/" data-parsley-validate="" autocomplete="off">>
                <input type="hidden" name="connectMode" id="connectMode" value="login">
                <input type="hidden" name="spage" id="spage" value="dashboard">
                <input type="hidden" name="fpage" id="fpage" value="login">
                <input type="hidden" name="access" id="access" value="userID"> 

					<div class="login100-form-avatar">
						<img src="./images/logo/logo_login.png" alt="AVATAR">
					</div>

					<span class="login100-form-title" style="padding: 20px">
						회원 로그인
					</span>

                    
					<div class="wrap-input100 validate-input m-b-10">
						<input class="input100" type="text"  name="userID"  required="" placeholder="★ 아이디">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-10">
						<input class="input100" type="password" name="password"  required="" placeholder="★ 비밀번호">
						<span class="focus-input100"></span>
					</div>

					<div class="container-login100-form-btn p-t-10">
						<button class="login100-form-btn btn-green">
							로그인
						</button>
					</div>

					<div class="container-login100-form-btn p-t-10">
						<a href="sign_up.php" class="login100-form-btn btn-blue">
							회원가입
						</a>
					</div>

				</form>
			</div>
		</div>
	</div>


<!--===============================================================================================-->
<script src="assets/vendor/bootstrap/js/popper.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/js/main.js"></script>
	<script src="assets/js/particles.min.js"></script>
	<script src="assets/js/app.js"></script>
    <script src="assets/vendor/parsley/parsley.min.js"></script>
	<script src="assets/vendor/parsley/lang/ko.js"></script>
</body>
</html>